<?php
require 'vendor/autoload.php';
\Stripe\Stripe::setApiKey("sk_test_51uftimvTLw53nTgWlI44byq");

// Get the credit card details submitted by the form
$token = $_GET['stripeToken'];

// Create the charge on Stripe's servers - this will charge the user's card
try {
$charge = \Stripe\Charge::create(array(
  "amount" => 1000, // amount in cents, again
  "currency" => "usd",
  "source" => $token,
  "description" => "Example charge")
);
echo "successfull";
} catch(\Stripe\Error\Card $e) {
  // The card has been declined
}
?>